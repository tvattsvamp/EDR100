%   used to create library file

vkm = [10 50 90 130 50 130 50 130]
a = [0 0 0 0 2.5 1 0 0]
alpha = [0 0 0 0 0 0 0.31 0.07]
save library.mat vkm a alpha
