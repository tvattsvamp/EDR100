import pandas as pd
df = pd.read_csv('clean_nedc.csv',index_col=0)
lst = []
lstv = []
lstt = []
for i in range(1,91):
    lst.append(df.time[i] - df.time[i -1])

for k in range(len(lst)):
    for j in range(lst[k]):
        lstv.append(df.velocity[k])
for g in range(len(lstv)):
    lstt.append(g)

df = pd.DataFrame({'time':[],'velocity[m/s]':[]})
df.to_csv('NEDC.csv',mode='a',index=False, header=True)
for i in range(len(lstt)):
    df = pd.DataFrame({'time':[lstt[i]],'velocity[m/s]':[lstv[i]]})
    df.to_csv('NEDC.csv',mode='a',index=False, header=False)
